#!/usr/bin/python
import string
import os

s = open("./Countries-list-hyphenated.txt","r+")
for line in s.readlines():
   print (line)
 
#    s.write("'%s'" % line[:-1])
   s.write("'" + line[:-1] + "',")
    
#    print(n.format("'", "',")
#    string.write('\"' + line + '\",')
#    string.replace(line, 'mickey','minnie')
#    print line
s.close()
